import os
import json
import requests
import google.generativeai as genai
import urllib.request # Python's built-in, native downloader
from gtts import gTTS
from moviepy.editor import ImageClip, AudioFileClip, concatenate_videoclips
from PIL import Image # Python's local image generator
import urllib.request
import os


# --- SETUP YOUR API KEY HERE ---
GEMINI_API_KEY = "YOUR_API_KEY_HERE"
genai.configure(api_key=GEMINI_API_KEY)

# 1. Setup paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
WORKSPACE = os.path.join(SCRIPT_DIR, "workspace")
AUDIO_PATH = os.path.join(WORKSPACE, "voiceover.mp3")
OUTPUT_PATH = os.path.join(WORKSPACE, "final_short.mp4")

# Ensure workspace exists
os.makedirs(WORKSPACE, exist_ok=True)

# 2. Automated Idea & Script Generation
print("🧠 Generating a brand new video idea via Gemini AI...")
try:
    model = genai.GenerativeModel('gemini-2.0-flash')
    prompt = """
    Output a valid JSON object for a 30-second YouTube Short in the style of Zack D. Films. 
    Give me a weird, fascinating biology or human body fact.
    Keys needed:
    "script": the spoken text.
    "image_prompts": an array of exactly 4 prompts describing 3D blender-style, macro, hyper-detailed medical renders to match the script.
    Output ONLY the raw JSON, absolutely no markdown formatting or backticks.
    """
    response = model.generate_content(prompt)
    
    clean_json = response.text.replace("```json", "").replace("```", "").strip()
    data = json.loads(clean_json)
    
    script_text = data['script']
    prompts = data['image_prompts']
    print(f"   ✅ Idea generated! Topic snippet: '{script_text[:50]}...'")
    
except Exception as e:
    print(f"   ⚠️ Gemini Rate Limit Hit (429).")
    print("   🔄 Activating offline fallback script to keep the pipeline moving...")
    
    # The Offline Backup Brain
    script_text = "Did you know your blood vessels are so long that if you laid them end to end, they would wrap around the Earth more than twice? Your body contains over 60,000 miles of arteries, veins, and capillaries. This massive highway system constantly pushes oxygen to every single cell, keeping you alive."
    prompts = [
        "Hyper detailed 3D medical animation render of a dense network of glowing red blood vessels",
        "Macro 3D blender render of the Earth tightly wrapped in glowing red arteries",
        "Microscopic 3D render of a single capillary delivering glowing oxygen to a blue cell",
        "Cinematic 3D anatomy render of a beating human heart pumping bright red blood"
    ]
# 3. Generate Voiceover
print("🎙️ Generating Voiceover via Google TTS...")
try:
    tts = gTTS(text=script_text, lang='en', tld='co.uk', slow=False)
    tts.save(AUDIO_PATH)
    print("   ✅ Voiceover saved successfully!")
except Exception as e:
    print(f"   ❌ Voice generation failed: {e}")
    exit()

# 4. Fetch ACTUAL Images (Unsplash Static Developer CDN)
print("🎨 Fetching real biology images from static CDN...")
image_files = []

# Permanent, unblocked static CDN URLs for biology/medical images
fallback_urls = [
    "https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?w=1080&q=80", # Cells/Virus
    "https://images.unsplash.com/photo-1530026405186-ed1f139313f8?w=1080&q=80", # Anatomy
    "https://images.unsplash.com/photo-1559757175-5700dde675bc?w=1080&q=80", # Microscope/Lab
    "https://images.unsplash.com/photo-1576086213369-97a306d36557?w=1080&q=80"  # Medical Science
]

for i in range(4):
    print(f"   -> Downloading Real Image {i+1}...")
    filename = os.path.join(WORKSPACE, f"scene_{i}.jpg")
    
    try:
        req = urllib.request.Request(
            fallback_urls[i], 
            headers={'User-Agent': 'Mozilla/5.0'}
        )
        
        with urllib.request.urlopen(req) as response, open(filename, 'wb') as out_file:
            out_file.write(response.read())
            
        image_files.append(filename)
        print(f"      ✅ Successfully secured real Image {i+1}")
        
    except Exception as e:
        print(f"      ❌ Download error: {e}")
        exit()
# 5. Assembly & 3D Motion Simulation
print("🎬 Assembling Video and Applying Simulated 3D Motion...")
audio = AudioFileClip(AUDIO_PATH)
duration_per_image = audio.duration / len(image_files)

clips = []
for img_path in image_files:
    clip = ImageClip(img_path).set_duration(duration_per_image)
    
    # Scale up vertically to avoid black bars crashing MoviePy
    clip = clip.resize(height=2100)
    clip = clip.crop(x_center=clip.w/2, y_center=clip.h/2, width=1080, height=1920)
    
    # The programmatic 3D camera pan (10% Ken Burns zoom)
    clip = clip.resize(lambda t: 1 + 0.10 * (t / duration_per_image))
    clip = clip.crop(x_center=clip.w/2, y_center=clip.h/2, width=1080, height=1920)
    
    clips.append(clip)

final_video = concatenate_videoclips(clips, method="compose")
final_video = final_video.set_audio(audio)

# 6. Render Final MP4
print("🚀 Rendering Final MP4. This may take a minute...")
final_video.write_videofile(OUTPUT_PATH, fps=24, codec="libx264", audio_codec="aac", logger=None)
print(f"✅ Success! Brand new dynamic video saved to workspace/final_short.mp4")